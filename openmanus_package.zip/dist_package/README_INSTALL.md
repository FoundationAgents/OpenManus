# OpenManus Installation Guide

This package contains the OpenManus application wheel and its dependencies list.

## Prerequisites

- Python 3.10 or newer.
  - **Note on `browser-use` dependency**: 
    - The included `requirements.txt` specifies `browser-use==0.2.4`. This version *may* require Python 3.11+. 
    - If you encounter issues with `browser-use` on Python 3.10, you might need to use a Python 3.11+ environment.
    - Alternatively, if you specifically need the older `browser-use~=0.1.40` (which definitely requires Python 3.11+), you would need to adjust `requirements.txt` accordingly and ensure a compatible Python environment.

## Installation Steps

1.  **Create and activate a virtual environment (Recommended)**:
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows: venv\Scripts\activate
    ```

2.  **Install dependencies**:
    Navigate to the directory containing this README (i.e., the `dist_package` directory).
    Run the following command to install all required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

3.  **Install OpenManus**:
    After installing the dependencies, install the OpenManus application using the wheel file:
    ```bash
    pip install openmanus-0.1.0-py3-none-any.whl
    ```

4.  **Run OpenManus**:
    Once the installation is complete, you can run the application:
    ```bash
    openmanus
    ```
